//
//  TakeHomeAssignmentApp.swift
//  TakeHomeAssignment
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import SwiftUI

@main
struct TakeHomeAssignmentApp: App {
    var body: some Scene {
        WindowGroup {
            TransactionList()
        }
    }
}
