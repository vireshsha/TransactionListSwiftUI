//
//  TransactionRowView.swift
//  TakeHomeAssignment
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//


import SwiftUI

struct TransactionRowView: View {
    let transaction: Transaction
    
    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 4) {
                Text(transaction.merchantName)
                    .font(.headline)
                Text(transaction.fromDisplayText)
                    .font(.subheadline)
                    .foregroundColor(.secondary)
            }
            Spacer()
            Text(transaction.formattedAmount())
                .font(.subheadline)
                .foregroundColor(transaction.type == .credit ? .green : .red)
        }
        .padding(.vertical, 8)
        .accessibilityElement(children: .combine)
    }
}

