//
//  Transaction.swift
//  TakeHomeAssignment
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import Foundation

public enum TransactionType: String, Codable, CaseIterable {
    case credit = "CREDIT"
    case debit = "DEBIT"
}

public struct MoneyAmount: Codable, Equatable, Hashable {
    public let value: Decimal
    public let currency: String
}

public struct Transaction: Identifiable, Codable, Equatable, Hashable {
    public let id: String
    public let type: TransactionType
    public let merchantName: String
    public let details: String?           // renamed from 'description' to avoid conflict
    public let amount: MoneyAmount
    public let postedDate: Date
    public let fromAccount: String
    public let fromCardNumber: String

    public var shortCardSuffix: String {
        let suffix = fromCardNumber.suffix(4)
        return String(suffix)
    }

    public var fromDisplayText: String {
        "\(fromAccount) (\(shortCardSuffix))"
    }

    public func formattedAmount(locale: Locale = Locale(identifier: "en_CA")) -> String {
        amount.formattedAmount(locale: locale)
    }

    enum CodingKeys: String, CodingKey {
        case id = "key"
        case type = "transaction_type"
        case merchantName = "merchant_name"
        case details = "description"          // map JSON "description" to `details`
        case amount
        case postedDate = "posted_date"
        case fromAccount = "from_account"
        case fromCardNumber = "from_card_number"
    }
}

public struct TransactionListResponse: Codable, Equatable {
    public let transactions: [Transaction]
}

private extension Decimal {
    var asNSDecimalNumber: NSDecimalNumber { NSDecimalNumber(decimal: self) }
}

public extension MoneyAmount {
    func formattedAmount(locale: Locale = Locale(identifier: "en_CA")) -> String {
        let formatter = NumberFormatter()
        formatter.locale = locale
        formatter.numberStyle = .currency
        formatter.currencyCode = currency
        formatter.minimumFractionDigits = 2
        formatter.maximumFractionDigits = 2
        return formatter.string(from: value.asNSDecimalNumber) ?? "\(value)"
    }
}
