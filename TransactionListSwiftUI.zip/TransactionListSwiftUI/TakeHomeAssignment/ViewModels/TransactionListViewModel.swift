//
//  TransactionListViewModel.swift
//  TakeHomeAssignment
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import Foundation
import Combine

@MainActor final class TransactionListViewModel: ObservableObject {
    @Published private(set) var transactions: [Transaction] = []
    @Published var isLoading: Bool = false
    @Published var errorMessage: String?

    private let service: TransactionServiceProtocol

    init(service: TransactionServiceProtocol? = nil) {
        self.service = service ?? TransactionService()
    }

    func loadTransactions() async {
        isLoading = true
        defer { isLoading = false }

        do {
            errorMessage = nil
            transactions = try await service.fetchTransactions()
        } catch {
            errorMessage = error.localizedDescription
        }
    }
}
