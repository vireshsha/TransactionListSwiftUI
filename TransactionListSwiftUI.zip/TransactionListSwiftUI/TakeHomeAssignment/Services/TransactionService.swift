//
//  TransactionService.swift
//  TakeHomeAssignment
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import Foundation

public enum TransactionServiceError: Error, LocalizedError {
    case resourceNotFound(String)
    case decodingFailed
    
    public var errorDescription: String? {
        switch self {
        case .resourceNotFound(let file):
            return "\(file) not found."
        case .decodingFailed:
            return "Failed to decode transactions."
        }
    }
}

public protocol TransactionServiceProtocol {
    func fetchTransactions() async throws -> [Transaction]
}

public struct TransactionService: TransactionServiceProtocol {
    
    public init() {}
    
    public func fetchTransactions() async throws -> [Transaction] {
        guard let url = Bundle.main.url(forResource: "transaction-list", withExtension: "json") else {
            throw TransactionServiceError.resourceNotFound("transaction-list.json")
        }
        let data = try Data(contentsOf: url)
        return try Self.decodeTransactions(from: data)
    }
    
    public static func decodeTransactions(from data: Data) throws -> [Transaction] {
        let decoder = JSONDecoder()
        let df = DateFormatter()
        df.calendar = Calendar(identifier: .iso8601)
        df.locale = Locale(identifier: "en_US_POSIX")
        df.timeZone = TimeZone(secondsFromGMT: 0)
        df.dateFormat = "yyyy-MM-dd"
        decoder.dateDecodingStrategy = .formatted(df)
        
        do {
            let response = try decoder.decode(TransactionListResponse.self, from: data)
            return response.transactions
        } catch {
            throw TransactionServiceError.decodingFailed
        }
    }
}
