//
//  TakeHomeAssignmentUITestsLaunchTests.swift
//  TakeHomeAssignmentUITests
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import XCTest

final class TakeHomeAssignmentUITestsLaunchTests: XCTestCase {
    
    private let timeout = 5.0

    // Run this test class for each UI configuration
    override class var runsForEachTargetApplicationUIConfiguration: Bool {
        true
    }

    override func setUpWithError() throws {
        // Stop immediately when a failure occurs
        continueAfterFailure = false
    }

    override func tearDownWithError() throws {
        // Clean up resources if needed
    }

    @MainActor
    func testAppLaunches() throws {
        let app = XCUIApplication()
        app.launch()

        // Ensure main list appears
        let transactionList = app.descendants(matching: .any)["transactionList"]
        XCTAssertTrue(transactionList.waitForExistence(timeout: timeout), "Transaction list did not appear after app launch")

        // Take a screenshot for reference
        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = "Launch Screen"
        attachment.lifetime = .keepAlways
        add(attachment)
    }

    @MainActor
    func testNavigationBarTitle() throws {
        let app = XCUIApplication()
        app.launch()

        // Verify the navigation title exists
        let navTitle = app.staticTexts["Transactions"]
        XCTAssertTrue(navTitle.waitForExistence(timeout: timeout), "Navigation bar title not visible")
    }

    @MainActor
    func testFirstTransactionCellExists() throws {
        let app = XCUIApplication()
        app.launch()

        // Wait for the list to appear
        let list = app.descendants(matching: .any)["transactionList"]
        XCTAssertTrue(list.waitForExistence(timeout: timeout))

        // Wait for the first cell to appear
        let firstCell = list.descendants(matching: .any)
            .matching(NSPredicate(format: "identifier BEGINSWITH 'transactionCell_'"))
            .firstMatch
        XCTAssertTrue(firstCell.waitForExistence(timeout: timeout), "No transaction cell found on launch")
    }
}
