//
//  TakeHomeAssignmentUITests.swift
//  TakeHomeAssignmentUITests
//
//  Created by VIRESH KUMAR SHARMA on 2026-03-18.
//

import XCTest

final class TakeHomeAssignmentUITests: XCTestCase {
    
    private let timeout = 5.0

    @MainActor
    func testOpenFirstTransaction() throws {
        let app = XCUIApplication()
        app.launch()

        // SwiftUI List may appear as a collectionView instead of table
        let list = app.collectionViews["transactionList"]
        
        XCTAssertTrue(
            list.waitForExistence(timeout: timeout),
            "Transaction list did not appear"
        )

        // Wait for at least one cell
        let firstCell = list.cells.firstMatch
        XCTAssertTrue(
            firstCell.waitForExistence(timeout: timeout),
            "No transaction cells found"
        )

        firstCell.tap()

        // Verify detail screen opened
        XCTAssertTrue(
            app.navigationBars["Transaction Details"].waitForExistence(timeout: timeout)
        )
    }
    
    @MainActor
    func testNavigateToTransactionDetail() throws {
        let app = XCUIApplication()
        app.launch()

        let list = app.collectionViews["transactionList"]
        XCTAssertTrue(list.waitForExistence(timeout: timeout))

        let firstCell = list.cells.firstMatch
        XCTAssertTrue(firstCell.waitForExistence(timeout: timeout))

        firstCell.tap()

        let detailTitle = app.navigationBars["Transaction Details"]
        XCTAssertTrue(detailTitle.waitForExistence(timeout: timeout), "Detail screen did not open")
    }
    
    @MainActor
    func testCloseButtonReturnsToList() throws {
        let app = XCUIApplication()
        app.launch()

        let list = app.collectionViews["transactionList"]
        XCTAssertTrue(list.waitForExistence(timeout: timeout))

        let firstCell = list.cells.firstMatch
        firstCell.tap()

        let closeButton = app.buttons["Close"]
        XCTAssertTrue(closeButton.waitForExistence(timeout: timeout))

        closeButton.tap()

        XCTAssertTrue(list.waitForExistence(timeout: timeout), "Did not return to transaction list")
    }
    
    @MainActor
    func testTransactionCellDisplaysData() throws {
        let app = XCUIApplication()
        app.launch()

        let list = app.collectionViews["transactionList"]
        XCTAssertTrue(list.waitForExistence(timeout: timeout))

        let cell = list.cells.firstMatch
        XCTAssertTrue(cell.exists)

        XCTAssertTrue(cell.staticTexts.count > 0, "Transaction cell has no visible data")
    }
    
    @MainActor
    func testScrollingPerformance() throws {
        let app = XCUIApplication()
        app.launch()

        let list = app.collectionViews["transactionList"]
        XCTAssertTrue(list.waitForExistence(timeout: timeout))
        XCTAssertTrue(list.cells.firstMatch.waitForExistence(timeout: timeout))

        measure {
            list.swipeUp()
            list.swipeDown()
        }
    }
    
    @MainActor
    func testMultipleTransactionsLoaded() throws {
        let app = XCUIApplication()
        app.launch()

        let list = app.collectionViews["transactionList"]
        XCTAssertTrue(list.waitForExistence(timeout: timeout))

        XCTAssertGreaterThan(list.cells.count, 1, "Expected multiple transactions")
    }
    
    @MainActor
    func testBackNavigationFromDetail() throws {
        let app = XCUIApplication()
        app.launch()

        let list = app.collectionViews["transactionList"]
        XCTAssertTrue(list.waitForExistence(timeout: timeout))

        let firstCell = list.cells.firstMatch
        firstCell.tap()

        let backButton = app.navigationBars.buttons.firstMatch
        XCTAssertTrue(backButton.waitForExistence(timeout: timeout))

        backButton.tap()

        XCTAssertTrue(list.waitForExistence(timeout: timeout))
    }
    
    @MainActor
    func testNoErrorMessageShown() throws {
        let app = XCUIApplication()
        app.launch()

        let errorText = app.staticTexts.containing(NSPredicate(format: "label CONTAINS 'error'")).firstMatch
        XCTAssertFalse(errorText.exists)
    }
    
    @MainActor
    func testTransactionCellsExist() throws {
        let app = XCUIApplication()
        app.launch()

        let list = app.collectionViews["transactionList"]
        XCTAssertTrue(list.waitForExistence(timeout: timeout))

        let cells = app.descendants(matching: .any)
            .matching(NSPredicate(format: "identifier BEGINSWITH 'transactionCell_'"))

        XCTAssertTrue(cells.firstMatch.waitForExistence(timeout: timeout))
    }
}
